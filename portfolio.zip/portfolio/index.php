<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raja Mistri | Web Developer & WordPress Expert</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <!-- Loading Screen -->
    <div class="loader" id="loader">
        <div class="loader-content">
            <div class="loader-spinner"></div>
            <div class="loader-text">Loading Portfolio...</div>
        </div>
    </div>

    <!-- Custom Cursor -->
    <div class="cursor" id="cursor"></div>
    <div class="cursor-dot" id="cursorDot"></div>

    <!-- Particle Background -->
    <canvas id="particles-canvas"></canvas>

    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <a href="#" class="nav-logo">Developer Raja<span>.</span></a>
        <ul class="nav-links">
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#contact" class="nav-cta">Hire Me</a></li>
        </ul>
        <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobileMenu">
        <a href="#about" onclick="closeMobileMenu()">About</a>
        <a href="#services" onclick="closeMobileMenu()">Services</a>
        <a href="#skills" onclick="closeMobileMenu()">Skills</a>
        <a href="#projects" onclick="closeMobileMenu()">Projects</a>
        <a href="#testimonials" onclick="closeMobileMenu()">Testimonials</a>
        <a href="#contact" onclick="closeMobileMenu()">Contact</a>
    </div>

    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-bg-gradient"></div>
        <div class="hero-bg-gradient"></div>
        <div class="hero-container">
            <div class="hero-content">
                <div class="hero-badge">
                    <span class="dot"></span>
                    Available for freelance work
                </div>
                <h1 class="hero-title">
                    <span class="line">Hi, I'm <span class="gradient-text">Raja Mistri</span></span>
                    <span class="line">Web Developer &</span>
                    <span class="line">WordPress Expert</span>
                </h1>
                <p class="hero-subtitle">
                    I build stunning websites and WordPress solutions that help businesses grow. Specializing in custom themes, plugins, and responsive web development from Kolkata, India.
                </p>
                <div class="hero-buttons">
                    <a href="#projects" class="btn btn-primary">
                        <i class="fas fa-rocket"></i> View My Work
                    </a>
                    <a href="#contact" class="btn btn-secondary">
                        <i class="fas fa-envelope"></i> Get In Touch
                    </a>
                </div>
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number" data-target="30">0</div>
                        <div class="stat-label">Projects Done</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number" data-target="2">0</div>
                        <div class="stat-label">Year Experience</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number" data-target="25">0</div>
                        <div class="stat-label">Happy Clients</div>
                    </div>
                </div>
            </div>
            <div class="hero-visual">
                <div class="hero-image-wrapper">
                    <div class="hero-image-ring"></div>
                    <div class="hero-image">
                        <span class="hero-image-placeholder"></span>
                        <img src="avatar1.webp" alt="" width="100%" height="auto">
                    </div>
                    <div class="floating-card">
                        <div class="floating-card-icon" style="background: rgba(33,117,155,0.2);">
                            <i class="fab fa-wordpress" style="color: #21759b;"></i>
                        </div>
                        <div>
                            <div class="floating-card-text">Laravel</div>
                            <div class="floating-card-sub">Expert</div>
                        </div>
                    </div>
                    <div class="floating-card">
                        <div class="floating-card-icon" style="background: rgba(33,117,155,0.2);">
                            <i class="fab fa-wordpress" style="color: #21759b;"></i>
                        </div>
                        <div>
                            <div class="floating-card-text">WordPress</div>
                            <div class="floating-card-sub">Expert</div>
                        </div>
                    </div>
                    <div class="floating-card">
                        <div class="floating-card-icon" style="background: rgba(119,123,180,0.2);">
                            <i class="fab fa-php" style="color: #777BB4;"></i>
                        </div>
                        <div>
                            <div class="floating-card-text">PHP</div>
                            <div class="floating-card-sub">Backend</div>
                        </div>
                    </div>
                    <div class="floating-card">
                        <div class="floating-card-icon" style="background: rgba(0,212,170,0.2);">
                            <i class="fas fa-check-circle" style="color: #00d4aa;"></i>
                        </div>
                        <div>
                            <div class="floating-card-text">30+ Projects</div>
                            <div class="floating-card-sub">Completed</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Tech Marquee -->
    <div class="tech-marquee">
        <div class="marquee-content">
            <div class="marquee-item"><i class="fab fa-html5" style="color: #e34f26;"></i> HTML5</div>
            <div class="marquee-item"><i class="fab fa-css3-alt" style="color: #1572b6;"></i> CSS3</div>
            <div class="marquee-item"><i class="fab fa-js-square" style="color: #f7df1e;"></i> JavaScript</div>
            <div class="marquee-item"><i class="fab fa-bootstrap" style="color: #7952b3;"></i> Bootstrap</div>
            <div class="marquee-item"><i class="fab fa-wordpress" style="color: #21759b;"></i> WordPress</div>
            <div class="marquee-item"><i class="fab fa-php" style="color: #777BB4;"></i> PHP</div>
            <div class="marquee-item"><i class="fas fa-database" style="color: #00758f;"></i> MySQL</div>
            <div class="marquee-item"><i class="fas fa-puzzle-piece" style="color: #00d4aa;"></i> Plugins</div>
            <div class="marquee-item"><i class="fab fa-html5" style="color: #e34f26;"></i> HTML5</div>
            <div class="marquee-item"><i class="fab fa-css3-alt" style="color: #1572b6;"></i> CSS3</div>
            <div class="marquee-item"><i class="fab fa-js-square" style="color: #f7df1e;"></i> JavaScript</div>
            <div class="marquee-item"><i class="fab fa-bootstrap" style="color: #7952b3;"></i> Bootstrap</div>
            <div class="marquee-item"><i class="fab fa-wordpress" style="color: #21759b;"></i> WordPress</div>
            <div class="marquee-item"><i class="fab fa-php" style="color: #777BB4;"></i> PHP</div>
            <div class="marquee-item"><i class="fas fa-database" style="color: #00758f;"></i> MySQL</div>
            <div class="marquee-item"><i class="fas fa-puzzle-piece" style="color: #00d4aa;"></i> Plugins</div>
        </div>
    </div>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">About Me</span>
                <h2 class="section-title">Turning Ideas Into Reality</h2>
                <p class="section-subtitle">Passionate web developer crafting digital experiences</p>
            </div>
            <div class="about-grid">
                <div class="about-image-container reveal">
                    <div class="about-image">
                        <img src="avatar2.0.webp" alt="">
                    </div>
                    <div class="about-decoration"></div>
                </div>
                <div class="about-content reveal reveal-delay-2">
                    <h3>A Developer Who Understands Your Business</h3>
                    <p>
                        Hello! I'm Raja Mistri, a passionate web developer based in Kolkata, West Bengal. With 2 year of hands-on experience, I specialize in creating beautiful, functional websites and WordPress solutions that help businesses establish their online presence.
                    </p>
                    <p>
                        My expertise lies in WordPress theme customization, plugin development, and building responsive websites from scratch. I believe in writing clean, maintainable code and delivering projects that exceed client expectations. Whether you need a simple landing page or a complex e-commerce solution, I'm here to help!
                    </p>
                    <div class="about-info-grid">
                        <div class="about-info-item">
                            <div class="about-info-label">Name</div>
                            <div class="about-info-value">Raja Mistri</div>
                        </div>
                        <div class="about-info-item">
                            <div class="about-info-label">Location</div>
                            <div class="about-info-value">Kolkata, West Bengal</div>
                        </div>
                        <div class="about-info-item">
                            <div class="about-info-label">Experience</div>
                            <div class="about-info-value">2 Year</div>
                        </div>
                        <div class="about-info-item">
                            <div class="about-info-label">Availability</div>
                            <div class="about-info-value" style="color: var(--accent);">Open for Projects</div>
                        </div>
                    </div>
                    <a href="#contact" class="btn btn-primary" style="margin-top: 10px;">
                        <i class="fas fa-paper-plane"></i> Let's Work Together
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services" id="services">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">What I Do</span>
                <h2 class="section-title">My Services</h2>
                <p class="section-subtitle">Professional web development services tailored to your needs</p>
            </div>
            <div class="services-grid">
                <div class="service-card reveal reveal-delay-1">
                    <div class="service-icon" style="background: rgba(33,117,155,0.15); color: #21759b;">
                        <i class="fab fa-wordpress"></i>
                    </div>
                    <h3>WordPress Development</h3>
                    <p>Custom WordPress websites with themes tailored to your brand, optimized for performance and SEO.</p>
                </div>
                <div class="service-card reveal reveal-delay-2">
                    <div class="service-icon" style="background: rgba(108,99,255,0.15); color: var(--primary);">
                        <i class="fas fa-paint-brush"></i>
                    </div>
                    <h3>Theme Customization</h3>
                    <p>Transform any WordPress theme to match your vision with custom modifications and enhancements.</p>
                </div>
                <div class="service-card reveal reveal-delay-3">
                    <div class="service-icon" style="background: rgba(0,212,170,0.15); color: var(--accent);">
                        <i class="fas fa-puzzle-piece"></i>
                    </div>
                    <h3>Plugin Development</h3>
                    <p>Custom WordPress plugins to add unique functionality to your website that off-the-shelf solutions can't provide.</p>
                </div>
                <div class="service-card reveal reveal-delay-1">
                    <div class="service-icon" style="background: rgba(255,107,107,0.15); color: #ff6b6b;">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Responsive Design</h3>
                    <p>Websites that look perfect on all devices - from mobile phones to desktop computers.</p>
                </div>
                <div class="service-card reveal reveal-delay-2">
                    <div class="service-icon" style="background: rgba(119,123,180,0.15); color: #777BB4;">
                        <i class="fab fa-php"></i>
                    </div>
                    <h3>PHP Development</h3>
                    <p>Custom PHP solutions and backend development for dynamic web applications.</p>
                </div>
                <div class="service-card reveal reveal-delay-3">
                    <div class="service-icon" style="background: rgba(0,117,143,0.15); color: #00758f;">
                        <i class="fas fa-database"></i>
                    </div>
                    <h3>Database Design</h3>
                    <p>Efficient MySQL database design and optimization for your web applications.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section class="skills" id="skills">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">Tech Stack</span>
                <h2 class="section-title">My Skills</h2>
                <p class="section-subtitle">The technologies I use to build modern, reliable web experiences.</p>
            </div>

            <div class="tech-stack">
                <div class="tech-stack-intro reveal">
                    <span class="tech-stack-label">CRAFT</span>
                    <h3>Building with<br><span>modern technology.</span></h3>
                    <p>
                        I work across frontend, backend and CMS development,
                        combining practical experience with modern tools to
                        build responsive and production-ready web solutions.
                    </p>
                </div>

                <div class="tech-field reveal reveal-delay-1">
                    <div class="tech-field-glow"></div>

                    <div class="tech-item tech-item-1">
                        <i class="fab fa-html5"></i>
                        <span>HTML5</span>
                    </div>

                    <div class="tech-item tech-item-2">
                        <i class="fab fa-css3-alt"></i>
                        <span>CSS3</span>
                    </div>

                    <div class="tech-item tech-item-3">
                        <i class="fab fa-js-square"></i>
                        <span>JavaScript</span>
                    </div>

                    <div class="tech-item tech-item-4">
                        <i class="fab fa-wordpress"></i>
                        <span>WordPress</span>
                    </div>

                    <div class="tech-item tech-item-5">
                        <i class="fab fa-php"></i>
                        <span>PHP</span>
                    </div>

                    <div class="tech-item tech-item-6">
                        <i class="fab fa-laravel"></i>
                        <span>Laravel</span>
                    </div>

                    <div class="tech-item tech-item-7">
                        <i class="fab fa-react"></i>
                        <span>React</span>
                    </div>

                    <div class="tech-item tech-item-8">
                        <i class="fas fa-database"></i>
                        <span>MySQL</span>
                    </div>

                    <div class="tech-item tech-item-9">
                        <i class="fab fa-bootstrap"></i>
                        <span>Bootstrap</span>
                    </div>

                    <div class="tech-item tech-item-10">
                        <i class="fas fa-wind"></i>
                        <span>Tailwind</span>
                    </div>

                    <div class="tech-item tech-item-11">
                        <i class="fab fa-git-alt"></i>
                        <span>Git</span>
                    </div>

                    <div class="tech-item tech-item-12">
                        <i class="fas fa-plug"></i>
                        <span>REST API</span>
                    </div>

                    <div class="tech-field-center">
                        <span>WEB</span>
                        <small>DEVELOPMENT</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section class="projects" id="projects">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">My Work</span>
                <h2 class="section-title">Featured Projects</h2>
                <p class="section-subtitle">A collection of my recent work</p>
            </div>
            <div class="project-filters reveal">
                <button class="filter-btn active" data-filter="all">Recent Projects</button>
                <button class="filter-btn" data-filter="wordpress">WordPress</button>
                <button class="filter-btn" data-filter="website">Websites</button>
            </div>
            <div class="projects-grid">
                <!-- Project 1 - KF Academy -->
                <div class="project-card reveal reveal-delay-1" data-category="wordpress">
                    <span class="project-badge">Live</span>
                    <div class="project-image">
                        <img src="plutonic.png" alt="Mayapur Resources website thumbnail">
                        <div class="project-overlay">
                            <a href="https://plutonicesports.org/" target="_blank" title="Visit Website">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="project-content">
                        <div class="project-tech">
                            <span>WordPress</span>
                            <span>Custom Development</span>
                            <span>MySQL</span>
                        </div>
                        <h3>Plutonic Esports</h3>
                        <p>Competitive esports platform with custom tournament management, player registration, team systems, and automated match workflows.</p>
                    </div>
                </div>

                <!-- Project 2 - Mayapur Resources -->
                <div class="project-card reveal reveal-delay-2" data-category="wordpress">
                    <span class="project-badge">Live</span>
                    <div class="project-image">
                        <img src="image.png" alt="Mayapur Resources website thumbnail">
                        <div class="project-overlay">
                            <a href="https://mayapurresources.com" target="_blank" title="Visit Website">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="project-content">
                        <div class="project-tech">
                            <span>WordPress</span>
                            <span>Custom Plugins</span>
                            <span>MySQL</span>
                        </div>
                        <h3>Mayapur Resources</h3>
                        <p>Spiritual community website with content management and media galleries.</p>
                    </div>
                </div>

                <!-- Project 3 - E-Commerce -->
                <div class="project-card reveal reveal-delay-3" data-category="website">
                    <div class="project-image">
                        <img src="kfa.png" alt="Mayapur Resources website thumbnail">
                        <div class="project-overlay">
                            <a href="https://kfacademy.in" target="_blank" title="Visit Website">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                    <div class="project-content">
                        <div class="project-tech"> <span>WordPress</span> <span>Theme Customization</span> <span>PHP</span> </div>
                        <h3>KF Academy</h3>
                        <p>Educational platform with course management, student enrollment, and custom theme design.</p>
                    </div>
                </div>


            </div>
            <div style="text-align: center; margin-top: 50px;" class="reveal">
                <a href="#contact" class="btn btn-primary">
                    <i class="fas fa-envelope"></i> Discuss Your Project
                </a>
            </div>
        </div>
    </section>
    <!-- Testimonials Section -->
    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">Testimonials</span>
                <h2 class="section-title">What Clients Say</h2>
                <p class="section-subtitle">Feedback from people I've had the pleasure to work with</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card reveal reveal-delay-1">
                    <div class="testimonial-stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="testimonial-text">"Raja did an excellent job on our academy website. The design is professional, the site loads fast, and he was very responsive to our feedback. Highly recommended for WordPress projects!"</p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar" style="background: var(--gradient-1);">KF</div>
                        <div>
                            <div class="testimonial-name">KF Academy</div>
                            <div class="testimonial-role">Educational Institute</div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card reveal reveal-delay-2">
                    <div class="testimonial-stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="testimonial-text">"Working with Raja was a great experience. He understood our requirements perfectly and delivered a beautiful website for our community. His WordPress expertise is impressive!"</p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar" style="background: var(--gradient-2);">MR</div>
                        <div>
                            <div class="testimonial-name">Mayapur Resources</div>
                            <div class="testimonial-role">Community Organization</div>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card reveal reveal-delay-3">
                    <div class="testimonial-stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <p class="testimonial-text">"Raja is a talented developer who delivers quality work on time. He built our e-commerce store with all the features we needed. Great communication throughout the project!"</p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar" style="background: var(--gradient-3);">SK</div>
                        <div>
                            <div class="testimonial-name">Sunil Kumar</div>
                            <div class="testimonial-role">Business Owner</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container">
            <div class="section-header reveal">
                <span class="section-tag">Get In Touch</span>
                <h2 class="section-title">Let's Work Together</h2>
                <p class="section-subtitle">Have a project in mind? Let's discuss how I can help bring your ideas to life</p>
            </div>
            <div class="contact-grid">
                <div class="contact-info reveal">
                    <h3>Let's Talk About Your Project</h3>
                    <p>I'm available for freelance projects. Whether you need a new website, WordPress customization, or any web development work, feel free to reach out!</p>
                    <div class="contact-detail">
                        <div class="contact-detail-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div>
                            <div class="contact-detail-label">Email</div>
                            <div class="contact-detail-value">
                                <a href="mailto:raja333mistri@gmail.com">raja333mistri@gmail.com</a>
                            </div>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <div class="contact-detail-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div>
                            <div class="contact-detail-label">Phone</div>
                            <div class="contact-detail-value">
                                <a href="tel:+919064977898">+91 9064977898</a>
                            </div>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <div class="contact-detail-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div>
                            <div class="contact-detail-label">Location</div>
                            <div class="contact-detail-value">Kolkata, West Bengal, India</div>
                        </div>
                    </div>
                    <div class="contact-socials">
                        <a href="https://www.linkedin.com/in/rajamistri/" class="social-link" title="LinkedIn" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                        <a href="https://wa.me/919064977898" class="social-link" title="WhatsApp" target="_blank"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://www.instagram.com/r__a__j____a/" class="social-link" title="Instagram" target="_blank"><i class="fab fa-instagram" target="_blank"></i></a>
                        <a href="https://www.facebook.com/Myself.Raja.19" class="social-link" title="Facebook" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
                    <div class="contact-form reveal reveal-delay-2">

                        <form action="https://api.web3forms.com/submit" method="POST" id="contactForm">
                            <input type="hidden" name="access_key" value="0c9a3da2-1e8f-46f5-8876-9e1133ca9012">
                            <input type="hidden" name="subject" value="New Project Inquiry - Raja Mistri Portfolio">
                            <input type="hidden" name="from_name" value="Raja Mistri Portfolio">

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="name">Your Name *</label>
                                    <input type="text" id="name" name="name" placeholder="Your Name" required>
                                </div>

                                <div class="form-group">
                                    <label for="email">Your Email *</label>
                                    <input type="email" id="email" name="email" placeholder="abc@example.com" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="service">Service Interested In</label>
                                <select id="service" name="service">
                                    <option value="">Select a service</option>
                                    <option value="wordpress">WordPress Development</option>
                                    <option value="theme">Theme Customization</option>
                                    <option value="plugin">Plugin Development</option>
                                    <option value="website">Website Development</option>
                                    <option value="ecommerce">E-Commerce / WooCommerce</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="message">Project Details *</label>
                                <textarea id="message" name="message" placeholder="Tell me about your project..." required></textarea>
                            </div>

                            <button type="submit" class="form-submit">
                                <i class="fas fa-paper-plane"></i> Send Message
                            </button>

                        </form>
                    </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-brand">
                <a href="#" class="nav-logo">Raja<span>.</span></a>
                <p>Web Developer & WordPress Expert based in Kolkata, specializing in creating modern, responsive websites and custom WordPress solutions. Let's build something amazing together!</p>
            </div>
            <div class="footer-column">
                <h4>Quick Links</h4>
                <a href="#about">About Me</a>
                <a href="#services">Services</a>
                <a href="#skills">Skills</a>
                <a href="#projects">Projects</a>
                <a href="#contact">Contact</a>
            </div>
            <div class="footer-column">
                <h4>Services</h4>
                <a href="#services">WordPress Development</a>
                <a href="#services">Theme Customization</a>
                <a href="#services">Plugin Development</a>
                <a href="#services">Website Design</a>
            </div>
            <div class="footer-column">
                <h4>Recent Projects</h4>
                <a href="https://kfacademy.in" target="_blank"><i class="fas fa-external-link-alt"></i> KF Academy</a>
                <a href="https://mayapurresources.in" target="_blank"><i class="fas fa-external-link-alt"></i> Mayapur Resources</a>
            </div>
        </div>
        <div class="footer-bottom">
            <span>© 2026 Raja Mistri. All rights reserved.</span>
            <span>Made with <i class="fas fa-heart" style="color: #ff6b6b;"></i> in Kolkata, India</span>
        </div>
    </footer>

    <!-- Back to Top -->
    <a href="#hero" class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </a>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <i class="fas fa-check-circle"></i>
        <span>Message sent successfully!</span>
    </div>

    <script src="assets/js/script.js"></script>
</body>

</html>